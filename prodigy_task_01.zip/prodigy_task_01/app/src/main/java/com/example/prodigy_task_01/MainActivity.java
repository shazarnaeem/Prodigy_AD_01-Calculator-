package com.example.prodigy_task_01;

import android.annotation.SuppressLint;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    double in1 = 0, i2 = 0;
    TextView edittext1;
    boolean Add, Sub, Multiply, Divide, Remainder, deci;
    Button button_0, button_1, button_2, button_3, button_4, button_5, button_6, button_7, button_8, button_9, button_Add, button_Sub,
            button_Mul, button_Div, button_Equ, button_Del, button_Dot, button_Remainder, button_Clear;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_0 = findViewById(R.id.b0);
        button_1 = findViewById(R.id.b1);
        button_2 = findViewById(R.id.b2);
        button_3 = findViewById(R.id.b3);
        button_4 = findViewById(R.id.b4);
        button_5 = findViewById(R.id.b5);
        button_6 = findViewById(R.id.b6);
        button_7 = findViewById(R.id.b7);
        button_8 = findViewById(R.id.b8);
        button_9 = findViewById(R.id.b9);
        button_Dot = findViewById(R.id.bDot);
        button_Add = findViewById(R.id.badd);
        button_Sub = findViewById(R.id.bsub);
        button_Mul = findViewById(R.id.bmul);
        button_Div = findViewById(R.id.biv);
        button_Remainder = findViewById(R.id.BRemain);
        button_Del = findViewById(R.id.buttonDel);
        button_Equ = findViewById(R.id.buttoneql);
        button_Clear = findViewById(R.id.buttonClear);

        edittext1 = findViewById(R.id.display);

        View.OnClickListener numberClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                edittext1.setText(edittext1.getText().toString() + b.getText().toString());
            }
        };

        button_0.setOnClickListener(numberClickListener);
        button_1.setOnClickListener(numberClickListener);
        button_2.setOnClickListener(numberClickListener);
        button_3.setOnClickListener(numberClickListener);
        button_4.setOnClickListener(numberClickListener);
        button_5.setOnClickListener(numberClickListener);
        button_6.setOnClickListener(numberClickListener);
        button_7.setOnClickListener(numberClickListener);
        button_8.setOnClickListener(numberClickListener);
        button_9.setOnClickListener(numberClickListener);

        button_Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1 = Double.parseDouble(edittext1.getText().toString());
                    Add = true;
                    deci = false;
                    edittext1.setText(edittext1.getText().toString() + "+");
                }
            }
        });

        button_Sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1 = Double.parseDouble(edittext1.getText().toString());
                    Sub = true;
                    deci = false;
                    edittext1.setText(edittext1.getText().toString() + "-");
                }
            }
        });

        button_Mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1 = Double.parseDouble(edittext1.getText().toString());
                    Multiply = true;
                    deci = false;
                    edittext1.setText(edittext1.getText().toString() + "*");
                }
            }
        });

        button_Div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1 = Double.parseDouble(edittext1.getText().toString());
                    Divide = true;
                    deci = false;
                    edittext1.setText(edittext1.getText().toString() + "/");
                }
            }
        });

        button_Remainder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edittext1.getText().length() != 0) {
                    in1 = Double.parseDouble(edittext1.getText().toString());
                    Remainder = true;
                    deci = false;
                    edittext1.setText(edittext1.getText().toString() + "%");
                }
            }
        });

        button_Equ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = edittext1.getText().toString();
                if (Add || Sub || Multiply || Divide || Remainder) {
                    if (text.contains("+")) {
                        i2 = Double.parseDouble(text.split("\\+")[1]);
                        edittext1.setText(in1 + i2 + "");
                    } else if (text.contains("-")) {
                        i2 = Double.parseDouble(text.split("-")[1]);
                        edittext1.setText(in1 - i2 + "");
                    } else if (text.contains("*")) {
                        i2 = Double.parseDouble(text.split("\\*")[1]);
                        edittext1.setText(in1 * i2 + "");
                    } else if (text.contains("/")) {
                        i2 = Double.parseDouble(text.split("/")[1]);
                        edittext1.setText(in1 / i2 + "");
                    } else if (text.contains("%")) {
                        i2 = Double.parseDouble(text.split("%")[1]);
                        edittext1.setText(in1 % i2 + "");
                    }
                }

                Add = Sub = Multiply = Divide = Remainder = false;
            }
        });

        button_Del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = edittext1.getText().toString();
                if (text.length() > 0) {
                    edittext1.setText(text.substring(0, text.length() - 1));
                }
            }
        });

        button_Clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edittext1.setText("");
                in1 = i2 = 0;
                Add = Sub = Multiply = Divide = Remainder = false;
                deci = false;
            }
        });

        button_Dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!deci) {
                    edittext1.setText(edittext1.getText().toString() + ".");
                    deci = true;
                }
            }
        });
    }
}
